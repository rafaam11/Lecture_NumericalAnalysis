function y = myfunc(x)
y = -(-x^2 + 2*x - 1);