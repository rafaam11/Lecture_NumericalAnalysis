function A = my_factorial(n)
A = 1;
b = 0;
for i = 1:n
   
    b = b + 1;
    A = A * b;
end
